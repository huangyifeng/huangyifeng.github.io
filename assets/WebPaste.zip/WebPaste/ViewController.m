//
//  ViewController.m
//  WebPaste
//
//  Created by HuangYiFeng on 6/5/15.
//  Copyright (c) 2015 hyf. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property(nonatomic, weak)IBOutlet UIWebView *pasteWebView;

- (void)loadFromFile:(NSString *)fileName;

- (IBAction)copyURL:(id)sender;
- (IBAction)copyString:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self loadFromFile:@"TestHTML"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - private

- (void)loadFromFile:(NSString *)fileName
{
    NSString *filePath = [[NSBundle mainBundle] pathForResource:fileName ofType:@"html"];
    NSURL *fileURL = [NSURL fileURLWithPath:filePath];
    NSURLRequest *request = [NSURLRequest requestWithURL:fileURL];
    [self.pasteWebView loadRequest:request];
}

#pragma mark - IBAction

- (void)copyURL:(id)sender
{
    NSURL *url = [NSURL URLWithString:@"https://www.google.com"];
    [UIPasteboard generalPasteboard].URL = url;

}

- (void)copyString:(id)sender
{
    [UIPasteboard generalPasteboard].string = @"https://www.bing.com";
}

@end
